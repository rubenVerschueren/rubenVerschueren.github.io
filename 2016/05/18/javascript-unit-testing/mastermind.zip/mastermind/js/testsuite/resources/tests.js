//{ region variables
	var code = [];	
	var solution = [];
	var ColorsEnum = ["yellow", "green", "orange", "purple", "gray", "magenta"];	
	Object.freeze(ColorsEnum);
	var Mindgame;	
	var benchmark = 0;
//}

//{ region helpers
	/*
	 * helper function to setup an object
	 */
	function setupEnvironment()
	{
		//initialize environment and test data here
		code[0] = "yellow";
		code[1] = "orange";
		code[2] = "green";
		code[3] = "gray";		
	}

	function teardownEnvironment(){
		//teardown environment and reset/remove test data here
		code = [];
	}	
	
//}

setupModule("Code Quality test", null, null);
//{ region code quality
	//QHint test
	jsHintTest("QHint code quality: ", "../mastermind.js");
//}


setupModule("environment setup", setupEnvironment, teardownEnvironment);
//{ region initialization

	test("GenerateCode_test", function(){	
		var mastercode = Mastermind.GenerateCode(ColorsEnum);
			
		//test if code (array of 4 colors) is correctly generated
		ok( mastercode.length === 4, "code has correct length" );
					
		//all valid colors are selected		
		for(i = 0; i < 4; i++) {
			ok( $.inArray(mastercode[i], ColorsEnum ) !== -1, "code member " + i + " is a valid color");
		}
		 
	});
	
	test("GameInit_test", function(){
		Mastermind.InitGame(ColorsEnum);		
		equal( Mastermind.Game.Code.length, 4, "code initialised" );
	});
	
	test("RandomIntFromInterval_test", function(){
		var Number = Mastermind.RandomIntFromInterval(1, 10);		
		ok( Number > 1 && Number <= 10, "random number generated" );
	});
	
	SkippedTest('Igore me',function(){
		equal('foo','bar', 'this never happened');
	});
//}		

setupModule("gameplay", setupEnvironment, teardownEnvironment);
	test("setsolution_test", function(){
		//set up
		code = ["green","yellow","red","orange"];
		Mastermind.Game.Code = code;
				
		var DecodeTry = Mastermind.DecodeAttempt(code);		
		
		equal( DecodeTry, true , "review of user inputted code" );
	});
	
	test("Review_test", function(){
		//set up
		code = ["green","yellow","red","orange"];
		Mastermind.Game.Code = code;
				
		var result = Mastermind.Review("red", 2);
		equal( result, 2, "correct color, correct place" );
		
		result = Mastermind.Review("red", 1);
		equal( result, 1, "correct color, wrong place" );
		
		result = Mastermind.Review("mauve", 1);
		equal( result, 0, "wrong color, wrong place" );		
	});

setupModule("User Interface", setupEnvironment, teardownEnvironment);	
	test("RadiateResult_test", function(){		
		Mastermind.Game.Code = ["yellow", "green", "orange","purple"];
		var result = Mastermind.DecodeAttempt(["green", "yellow", "purple", "orange"]);		

		equal(result, 0, "correct colors, wrong order check" );		
		result = Mastermind.RadiateResult();
		ok(result, "Output generated");
		
	});
//}	
	
//{ region benchmarks
function formatOutput(data){
	//  GenerateCode_benchmark#test x 1,081,703 ops/sec �2.04% (54 runs sampled)
	var index1 = data.indexOf("#");
	var index2 = (data.indexOf("%")-5);
	var index3 = (data.indexOf("%")+1);
	var output = "<span class='name'>" + data.substr(0, index1) + "</span>";
	output += "<span class='opsSec'>" + data.substring((index1+7), index2) + "</span>";
	output += "<span class='percentage'>" + data.substring(index2, index3) + "</span>";
	output += "<span class='nrRuns'>" + data.substring((index3+1), data.length) + "</span>";

	return output;
}

if(benchmark ==1) {
	var suite = new Benchmark.Suite;

	// add tests
	suite.add('RandomIntFromInterval_benchmark#test', function() {
		var Number = Mastermind.RandomIntFromInterval(1, 10);
	})
	.add('GenerateCode_benchmark#test', function() {
	   var mastercode = Mastermind.GenerateCode(ColorsEnum);
	})
	.add('GameInit_benchmark#test', function() {
		Mastermind.InitGame(ColorsEnum);	
	})
	// add listeners
	.on('cycle', function(event) {
	  //console.log(String(event.target));

	  $("<div>"+formatOutput(String(event.target))+"</div>").appendTo("#benchmarks");
	})
	.on('complete', function() {
	  console.log('Fastest is ' + this.filter('fastest').pluck('name'));
	})
	.on('start',function(){	
		// do something when the suite starts
	})
	// run async
	.run({ 'async': true });
}

//}	