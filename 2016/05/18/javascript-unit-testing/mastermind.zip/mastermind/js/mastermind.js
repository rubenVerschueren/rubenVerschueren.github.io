var Mastermind = function () 
{ 
	var Game = {
		Code : []		
	};	
	var decodeTry = { 
		colors : [],
		review : []
	};	
	var reviewColors = ["black","white","red"];	
	var DecodeTries = [];
	var DecodeTryCount = 0;
	var gameWon = false;
	
	//initialize game 
	function InitGame (ColorsPool) {
		Game.Code = GenerateCode(ColorsPool);		
	}
	
	//verify code input with secret code
	function DecodeAttempt (code) {		
		var successCount = 0;
		var review = [];
		
		for(i=0; i< code.length; i++) {
			review[i] = Review(code[i], i);
			if(review[i] === 2) {
				successCount += 1;
			}
		}
		
		var DecodeTry = {};
		DecodeTry.colors = code;
		DecodeTry.review = review;
		DecodeTries[DecodeTryCount++] = DecodeTry;
		
		gameWon = successCount == 4;		
		return successCount == 4;
	}
	
	//verify one part of the code at a specific location
	function Review(codePart, location) {
		// 0 = wrong codePart
		// 1 = right codePart, wrong place
		// 2 = right codePart, right location
		var review = 0;
		if ($.inArray(codePart, Game.Code ) !== -1) {
			review = 1;
		}	
		if(codePart === Game.Code[location]){
			review = 2;
		}
		//console.log(codePart + " location " + location + " code: " + Game.code + " review" +review);
		return review;
	}
	
	//generate random number from interval
	function RandomIntFromInterval (min,max) {
		return Math.floor(Math.random()*(max-(min+1))+(min+1)); //incusive max, excl min
	}
	
	//generate random code of 4 colors
	function GenerateCode (colorsPool) {
		var Code = [];
		var selected = [];
		var x = 1 ;
		if(colorsPool !== undefined && colorsPool.length > 3)
		{
			var randIndex = RandomIntFromInterval(-1, (colorsPool.length ));						
			selected[0] = randIndex;					
			
			for (i=0;i<4;i++) {			
				Code[i] = colorsPool[randIndex];
				
				randIndex = RandomIntFromInterval(0, colorsPool.length);
				while($.inArray(randIndex, selected ) !== -1){
					randIndex = RandomIntFromInterval(-1, (colorsPool.length ));	
				}
				selected[x++] = randIndex;
			}
		}		
		return Code;
	}
	
	//display result
	function RadiateResult(){
		var style = "background-color:white;";
		if(gameWon){
			style = "background-color:green;color:#fff;";
		}
		var results = '<h3>decode attempts</h3><ul style="'+style+'">';
		for(i=0; i < DecodeTries.length; i++){
			var code = "";
			var review = "";
			results += '<li>';
			
			for(j=0; j < 4; j++){
				code +=  DecodeTries[i].colors[j] + " ";
				review += '<div style="display:inline-block;margin:3px;border:1px solid black;width:25px;height:25px;;background-color:' + reviewColors[DecodeTries[i].review[j]] + '"></div>';
			}
			results +=  '<div>' + (i+1) + ": " + code + '</div><div>' + review + '</div></li>';
		}
		results += "</ul>";
		return results;
	}
	
	return {
        //public functions
        GenerateCode: GenerateCode,
        InitGame : InitGame,
		RandomIntFromInterval : RandomIntFromInterval,
		DecodeAttempt : DecodeAttempt,
		Review : Review,
		RadiateResult : RadiateResult,
		
        //public variables
		Game : Game
    };
	
}();