
setupModule("Hello Qunit module", null, null);
test( "hello string test", function() {
  ok( "1" === "1", "Failed!" );
});

test( "hello integer test", function() {
  ok( 1 === 1, "Passed!" );
});

setupModule("skipped test module", null, null);
SkippedTest('Igore me',function(){
	equal('foo','bar', 'this never happened');
});

setupModule("Code Quality test", null, null);
//{ region code quality
	//QHint test
	qHint("QHint code quality: ", "resources/demo.js");
//}

	
//{ region benchmarks
function formatOutput(data){
	//  GenerateCode_benchmark#test x 1,081,703 ops/sec �2.04% (54 runs sampled)
	var index1 = data.indexOf("#");
	var index2 = (data.indexOf("%")-5);
	var index3 = (data.indexOf("%")+1);
	var output = "<span class='name'>" + data.substr(0, index1) + "</span>";
	output += "<span class='opsSec'>" + data.substring((index1+7), index2) + "</span>";
	output += "<span class='percentage'>" + data.substring(index2, index3) + "</span>";
	output += "<span class='nrRuns'>" + data.substring((index3+1), data.length) + "</span>";

	return output;
}

//put this variable somewhere meaningfull and don't polute the global scope!
var benchmark = 1;

if(benchmark ==1) {
	var suite = new Benchmark.Suite;

	// add tests
	suite.add('RandomIntFromInterval_benchmark#test', function() {
		var Number = RandomIntFromInterval(1, 10);
	})
	.add('GenerateCode_benchmark#test', function() {
	   var ColorsEnum = ["yellow", "green", "orange","purple","gray","magenta","red","white","black"]; 
	   var mastercode = GenerateCode(ColorsEnum);
	})	
	// add listeners
	.on('cycle', function(event) {
	  //console.log(String(event.target));

	  $("<div>"+formatOutput(String(event.target))+"</div>").appendTo("#benchmarks");
	})
	.on('complete', function() {
	  console.log('Fastest is ' + this.filter('fastest').pluck('name'));
	})
	.on('start',function(){	
		// do something when the suite starts
	})
	// run async
	.run({ 'async': true });
}

//}	