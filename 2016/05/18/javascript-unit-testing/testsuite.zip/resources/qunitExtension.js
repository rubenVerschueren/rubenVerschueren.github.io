//{ general setup
	function setupModule(name, setupFunction, tearDownFunction){
		module(name, {
			setup: function() {				
				if(setupFunction != undefined) {
					setupFunction();
				}
			},
			teardown: function() {
				if(tearDownFunction != undefined) {				
					tearDownFunction();
				}
			}
		});
	}
	
	//create a skipped test 
	QUnit.SkippedTest = function() {
	   QUnit.test(arguments[0] + ' (SKIPPED)', function() {
		   QUnit.expect(0);//dont expect any tests
		   //add some style to skipped tests
		   var li = document.getElementById(QUnit.config.current.id);
		   QUnit.done(function() {
			   li.style.background = '#FFFF99';
			   $(li).addClass("skipped");
		   });
	   });
	};
	SkippedTest = QUnit.SkippedTest;
	
	QUnit.done(function(details){		
		// add sort by type checkbox
		$("<input type='checkbox' id='sortByType' /><label for='sortByType'>Sort by test result type</label>").appendTo("#qunit-testrunner-toolbar");
		// add hide skipped checkbox
		$("<input type='checkbox' id='HideSkipped' /><label for='HideSkipped'>Hide skipped tests</label>").prependTo("#qunit-testrunner-toolbar");
		
		// display test results normal or sorted by type
		var $ol = $('#qunit-tests');
		var unsorted = $ol.children('li').get();		
		$("#sortByType").change(function() {
			if($(this).is(":checked")) {
				var array = ['pass', 'fail', 'skipped'];				
				var sorted = $ol.children('li').get().sort(function (o1, o2) {			
					return $.inArray(o1.className, array) - $.inArray(o2.className, array)
				});
				$.each(sorted, function () {
					$(this).appendTo($ol)
				});
			}
			else {
				$(this).html();
				$.each(unsorted, function () {
					$(this).appendTo($ol)
				});
			}
		});		

		//display number of skipped tests
		var skipped = $(".skipped").length;
		var results = "<span>" + skipped + " tests Skipped.</span>";		
		$("#qunit-testresult").html($("#qunit-testresult").html() + results);
		
		//hide skipped tests
		$("#HideSkipped").change(function() {
			if($(this).is(":checked")) {
				$(".skipped").hide();
			}
			else {
				$(".skipped").show();
			}
		});
		
		QUnit.jUnitReport = function(report) {
			console.log(report.xml);
		};
	});
//}