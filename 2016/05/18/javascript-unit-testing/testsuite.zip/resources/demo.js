//generate random number from interval
	function RandomIntFromInterval (min,max) {
		return Math.floor(Math.random()*(max-(min+1))+(min+1)); //incusive max, excl min
	}
	//generate random code of 4 colors
	function GenerateCode (colorsPool) {
		var Code = [];
		var selected = [];
		var x = 1 ;
		if(colorsPool !== undefined && colorsPool.length > 3)
		{
			var randIndex = RandomIntFromInterval(-1, (colorsPool.length ));						
			selected[0] = randIndex;					
			
			for (i=0;i<4;i++) {			
				Code[i] = colorsPool[randIndex];
				
				randIndex = RandomIntFromInterval(0, colorsPool.length);
				while($.inArray(randIndex, selected ) !== -1){
					randIndex = RandomIntFromInterval(-1, (colorsPool.length ));	
				}
				selected[x++] = randIndex;
			}
		}		
		return Code;
	}